var bebop = require('node-bebop');
var drone = bebop.createClient();
drone.connect(function() {
  drone.on("GPSFixStateChanged", function(data) {
    console.log("GPSFixStateChanged", data);
  });
  drone.on("MavlinkPlayErrorStateChanged", function(data) {
    console.log("MavlinkPlayErrorStateChanged", data);
  });
  drone.on("MavlinkFilePlayingStateChanged", function(data) {
    console.log("MavlinkFilePlayingStateChanged", data);
  });
  drone.on("AvailabilityStateChanged", function(data) {
    console.log("AvailabilityStateChanged", data);
    if(data.AvailabilityState === 1 && !alreadyFlying) {
      alreadyFlying = true;
      drone.Mavlink.start("/data/ftp/internal_000/flightplans/flightPlan.mavlink", 0);
    }
  });
  drone.on("ComponentStateListChanged", function(data) {
    console.log("ComponentStateListChanged", data);
  });
  drone.on("ready", function () {
    console.log("ready");
  });
  drone.on("battery", function (data) {
    console.log(data);
  });
  drone.on("landed", function () {
    console.log("landed");
  });
  drone.on("takingOff", function () {
    console.log("takingOff");
  });
  drone.on("hovering", function () {
    console.log("hovering");
  });
  drone.on("FlyingStateChanged", function () {
    console.log("FlyingStateChanged");
  });
  drone.on("BatteryStateChanged", function () {
    console.log("BatteryStateChanged");
  });
  drone.on("flying", function() {
    console.log("flying");
  });
  drone.on("landing", function() {
    console.log("landing");
  });
  // drone.on("unknown", function(data) {
  //   console.log("unknown", data);
  // });
});